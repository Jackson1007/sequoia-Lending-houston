# Sequoia-lending
Prototype for Sequoia’s commercial lending platform
